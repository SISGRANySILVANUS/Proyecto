<?php

    $conex = mysqli_connect("localhost","root","", "pruebaphp"); //'pruebaphp' es el nombre de la base de datos.
    

?>