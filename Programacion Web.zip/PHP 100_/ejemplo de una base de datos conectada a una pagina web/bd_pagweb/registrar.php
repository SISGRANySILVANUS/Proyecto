<?php
    include("con_bd.php");

    if( isset($_POST['registro'])){
        if(strlen($_POST['nombre']) >= 1 && strlen($_POST['email']) >= 1){
            $nombre   = trim($_POST['nombre']);
            $email    = trim($_POST['email']);
            $consulta ="INSERT INTO personas (nombre, correo) VALUES ('$nombre',' $email')"; //tuve que cambiar 'personas' que es el nombre de la table y
                                                                                             //y 'correo' que era el nombre de un atributo, junto con el
                                                                                             //nombre de la base de datos en con_bd
            $resultado= mysqli_query($conex,$consulta);
            if($resultado){
                ?>
                <h3 class = "ok"> Te has inscripto correctamente! </h3>
                <?php
            } else {
                ?>
                <h3 class="bad"> Ha ocurrido un error!!</h3>
                <?php
                }
        }else{
                ?>
                <h3 class = "bad"> Por favor complete los campos!!</h3>
                <?php

            }

        
    }
?>